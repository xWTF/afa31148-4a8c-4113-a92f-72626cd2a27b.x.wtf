XInputHID for Windows Server

Extracted from Windows 10 21H1 (19043.1052) by xWTF.
See https://afa31148-4a8c-4113-a92f-72626cd2a27b.x.wtf/2021/xbox-gamepad-driver-for-windows-server/ for more information.

2021/12/15
